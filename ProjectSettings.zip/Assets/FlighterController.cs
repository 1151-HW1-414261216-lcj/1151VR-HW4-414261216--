using UnityEngine;

public class FlightController : MonoBehaviour
{
    [Header("飛行設定")]
    public float forwardSpeed = 20f;
    public float sensitivity = 30f;

    [Header("音效設定")]
    public AudioClip engineClip;     // 飛機持續飛行引擎聲
    public AudioClip hitClip;        // 撞到障礙物音效
    public AudioClip passClip;       // 順利通過音效

    private AudioSource engineSource; // 引擎聲專用
    private AudioSource sfxSource;    // 碰撞/通過音效專用

    void Start()
    {
        // 自動檢查並設定 AudioSource
        AudioSource[] sources = GetComponents<AudioSource>();
        if (sources.Length < 2)
        {
            engineSource = gameObject.AddComponent<AudioSource>();
            sfxSource = gameObject.AddComponent<AudioSource>();
        }
        else
        {
            engineSource = sources[0];
            sfxSource = sources[1];
        }

        // 播放持續的引擎聲（循環播放）
        if (engineClip != null)
        {
            engineSource.clip = engineClip;
            engineSource.loop = true;
            engineSource.Play();
        }
    }

    void Update()
    {
        // 1. 持續向前飛行
        transform.Translate(Vector3.forward * forwardSpeed * Time.deltaTime);

        // 2. 鍵盤控制上下左右
        float moveX = 0f;
        float moveY = 0f;

        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) moveX = -1f;
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) moveX = 1f;
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)) moveY = 1f;
        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow)) moveY = -1f;

        Vector3 moveDirection = new Vector3(moveX, moveY, 0) * sensitivity * Time.deltaTime;
        transform.Translate(moveDirection);
    }

    // 碰撞檢測：撞到障礙物
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Obstacle"))
        {
            if (hitClip != null) sfxSource.PlayOneShot(hitClip);
            Debug.Log("撞到障礙物！");
        }
    }

    // 觸發檢測：順利通過特定區域
    // 觸發檢測：順利通過特定區域或障礙物旁
    // 觸發檢測：當穿過障礙物或終點的 Trigger 區域時
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Obstacle") || other.CompareTag("Goal"))
        {
            if (passClip != null)
            {
                sfxSource.PlayOneShot(passClip);
            }
            Debug.Log("順利通過障礙物！");
        }
    }
}